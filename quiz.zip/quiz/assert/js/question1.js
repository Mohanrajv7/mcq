var correct_answer;
var count    = 0;
var mark     = 0;
var data;
var question = document.querySelector("#question");
var option1  = document.querySelector("#option1") ;
var option2  = document.querySelector("#option2") ;
var option3  = document.querySelector("#option3") ;
var option4  = document.querySelector("#option4") ;
var result   = document.querySelector("#result") ;
var next   = document.querySelector("#next") ;
var display   = document.querySelector("#display") ;
var retry   = document.querySelector("#retry") ;
var start_btn=document.querySelector("#start_btn") ;
 result.style.display="none";
 retry.style.display="none";
 option1.style.display="none";
 option2.style.display="none";
 option3.style.display="none";
 option4.style.display="none";
function time()
{
	var start_date=new Date();
        start_time=start_date.getTime();
}
async function SendApiRequest(){
start_btn.style.display="none";
 let response = await fetch('https://opentdb.com/api.php?amount=10&category=17&difficulty=easy&type=multiple');
 console.log(response)
 data = await response.json()
 console.log(data)
 GetApiData(data)
}
function GetApiData(data){
 if(count<10)
 {
 result.style.display="none";
 result.innerHTML="";
 next.innerHTML="";
  option1.style.display="";
 option2.style.display="";
 option3.style.display="";
 option4.style.display="";
 var answers=[data.results[count].correct_answer,data.results[count].incorrect_answers[0],data.results[count].incorrect_answers[1],data.results[count].incorrect_answers[2]];
 correct_answer= answers[0];
 const array =[0,1,2,3];
 array.sort((a,b) => 0.5 - Math.random());

 question.innerHTML =(count+1)+". "+ data.results[count].question;
 option1.style.color="black";
 option1.innerHTML  = answers[array[0]];
 option1.setAttribute("onclick", "check(this,correct_answer)");

 option2.style.color="black";
 option2.innerHTML  = answers[array[1]];
 option2.setAttribute("onclick", "check(this,correct_answer)");

 option3.style.color="black";
 option3.innerHTML  = answers[array[2]];
 option3.setAttribute("onclick", "check(this,correct_answer)");

 option4.style.color="black";
 option4.innerHTML  = answers[array[3]];
 option4.setAttribute("onclick", "check(this,correct_answer)");
 count++;
}
else
{
  result.style.display="";
  next.innerHTML="";
  result.innerHTML="Quiz Complated";
  question.style.display="none";
  option1.style.display="none";
  option2.style.display="none";
  option3.style.display="none";
  option4.style.display="none";
  if(mark<5)
  {
  result.innerHTML+="<br>You Fail <br> Total Mark :"+mark;
  }
  else
  {
  result.innerHTML+="<br>You Pass <br> Total Mark :"+mark;
  }
   var end_date=new Date();
     var end_time=end_date.getTime();
	 var time=end_time-start_time;
	  time=Math.round(time/1000);
	  if(time<=60)
	  {
	  result.innerHTML+="<br><p>Time taken to finish the quiz :"+time+"sec</p>";
	  }
	  else
	  {
	  var in_minute=time/60;
	  result.innerHTML+="<br><p>Time taken to finish the quiz :"+in_minute.toFixed(2)+"min</p>";
	  }
	  mark=0;
	  count=0;
	  retry.style.display="";

}
}
function check(Selected_option,correct_answer){
	option1.setAttribute("onclick", "");
	option2.setAttribute("onclick", "");
	option3.setAttribute("onclick", "");
	option4.setAttribute("onclick", "");

	if(Selected_option.textContent==correct_answer)
	{
	Selected_option.insertAdjacentHTML("beforeend", "&#10004");
	Selected_option.style.color="green";
	next.innerHTML    = "<button id='next_btn' onclick='GetApiData(data)'> Next question</button>";
    mark++;
	}
	else
	{
	if(option1.textContent==correct_answer)
	{
	option1.insertAdjacentHTML("beforeend", "&#10004");
    option1.style.color="green";
	}
	if(option2.textContent==correct_answer)
	{
	option2.insertAdjacentHTML("beforeend", "&#10004");
    option2.style.color="green";
	}
	if(option3.textContent==correct_answer)
	{
	option3.insertAdjacentHTML("beforeend", "&#10004");
    option3.style.color="green";
	}
	if(option4.textContent==correct_answer)
	{
	option4.insertAdjacentHTML("beforeend", "&#10004");
    option4.style.color="green";
	}
	Selected_option.insertAdjacentHTML("beforeend", "&#10060");
	Selected_option.style.color="red";
	next.innerHTML    = "<button id='next_btn' onclick='GetApiData(data)'> Next question</button>";
	}
}