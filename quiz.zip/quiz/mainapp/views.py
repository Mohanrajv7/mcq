from django.shortcuts import render ,redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
# Create your views here.

from .models import *
def register(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()
        if request.method == "POST":
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account created for ' + user)
                return redirect("login")
        return render(request, "register.html", {'form': form})


def loginpage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == "POST":
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect("home")
            else:
                messages.info(request, 'Username or Password is incorrect')

        return render(request, "login.html", {})




@login_required(login_url='login')
def homepage(request):
    return render(request, 'homepage.html', {})

@login_required(login_url='login')
def geography(request):
    return render(request, 'geography.html', {})

@login_required(login_url='login')
def history(request):
    return render(request, 'history.html', {})

@login_required(login_url='login')
def general(request):
    return render(request, 'general.html', {})

@login_required(login_url='login')
def science(request):
    return render(request, 'science.html', {})

@login_required(login_url='login')
def logoutpage(request):
    logout(request)
    return redirect("login")